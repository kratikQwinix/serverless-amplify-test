"use strict";

const dynamoose = require("dynamoose");

dynamoose.local();

// NOTE - In NoSQL , ID wont be provided on creation of a document. We need to manually create

// -------DEFINE SCHEMA

const Schema = dynamoose.Schema;

const userSchema = new Schema({
  firstName: {
    type: String,
    required: true
  },
  lastName: {
    type: String,
    required: true
  }
});

let User = dynamoose.model("users", userSchema); //This line  creates table under the name users referring userSchema

exports.User = User; // To make schema available globally
