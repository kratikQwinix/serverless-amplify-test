"use strict";

const User = require("../models/user").User; // To use user model

module.exports.create = (event, context, callback) => {
  var params =
    typeof event.body == "object" ? event.body : JSON.parse(event.body);
  //   Here we are checking the type cuz , if we hit this Endpoint via postman , it wil be JSON  . In Lambda, its a JSON string.
  const new_user = new User({
    firstName: params.firstName,
    lastName: params.lastName
  });
  new_user.save(err => {
    console.log(err);
    return;
  });
  const response = {
    statusCode: 200,
    message: "User created"
  };
  //   WHat should happen when its a success.
  //   MAKE SURE THAT THERE IS ONLY 1 CALLBACK
  callback(null, response);
};
